# debezium
CDC spring boot app with debezium
