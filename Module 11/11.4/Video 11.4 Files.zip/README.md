## Flask and Jinja Web Server
## jrw@mit.edu
Set and get simple cookie
