from flask import Flask, render_template
import json

"""
A example for creating a Table that is sortable by its header
"""

app = Flask(__name__)
data = [{
  "Topic": "Pandas",
  "Primary use": "numbers and dataframes",
  "Did I have fun with it?": "Yes! It was great making dataframes"
},
 {
   "Topic": "Strapi",
  "Primary use": "Headless content management service",
  "Did I have fun with it?": "No. It was difficult to set up but was useful once completed."
}, {
   "Topic": "Cookies",
  "Primary use": "Client-server communication and authentication",
  "Did I have fun with it?": "Yes! It was cool to learn this topic"
}]
# other column settings -> http://bootstrap-table.wenzhixin.net.cn/documentation/#column-options
columns = [
  {
    "field": "Topic", # which is the field's name of data key 
    "title": "Topic", # display as the table header's name
    "sortable": True,
  },
  {
    "field": "Primary use",
    "title": "Primary use",
    "sortable": True,
  },
  {
    "field": "Did I have fun with it?",
    "title": "Did I have fun with it?",
    "sortable": True,
  }
]

#jdata=json.dumps(data)

@app.route('/')
def index():
    return render_template("table.html",
      data=data,
      columns=columns,
      title='Flask Bootstrap Table')


if __name__ == '__main__':
	#print jdata
  app.run(debug=True)