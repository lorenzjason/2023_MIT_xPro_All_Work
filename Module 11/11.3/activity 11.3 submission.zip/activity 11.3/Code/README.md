# flask-bootstrap-table
A simple example of use bootstrap-table and flask

Thanks to bootstrap-table, it's powerful and beautiful. Keep on learning.

* [bootstrap-table](https://github.com/wenzhixin/bootstrap-table)
* many other bootstrap-table examples can be found [here](http://issues.wenzhixin.net.cn/bootstrap-table/)
