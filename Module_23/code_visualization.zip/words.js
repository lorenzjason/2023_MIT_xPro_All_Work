scores = {
    "Engineering": 38,
    "Computation": 3,
}